import pdata from './TestData.jsx';

export default function Output(){
    return(
    <div>
      <h1>Output</h1>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Litres</th>
            <th>Kilometers</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {pdata.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.litres}</td>
              <td>{item.kilometers}</td>
              <td>{item.price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    );
}