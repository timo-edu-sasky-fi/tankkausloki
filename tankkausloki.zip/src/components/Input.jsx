
export default function Input() {

  return (
    <div className="input">
      <h1>Syöttö</h1>
      <form name="inputs">
        <label>Litrat</label><br />
        <input type="text" name="litres" /><br />

        <label>Ajetut km</label><br />
        <input type="text" name="kilometers"/><br />

        <label>Hinta per litra</label><br />
        <input type="text" name="price" /><br />

        <button type="submit">syötä</button>
      </form>
    </div>
  );
}
