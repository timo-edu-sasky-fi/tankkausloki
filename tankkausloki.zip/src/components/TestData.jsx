let pdata = [
  {
    id: "1",
    litres: "15",
    kilometers: "30000",
    price: "2.2"
  },
  {
    id: "2",
    litres: "20",
    kilometers: "30050",
    price: "1.9"
  },
  {
    id: "3",
    litres: "20",
    kilometers: "30150",
    price: "1.8"
  },
  {
    id: "4",
    litres: "40",
    kilometers: "30190",
    price: "2.0"
  }
];


export default pdata;
