import {
    LineChart,
    ResponsiveContainer,
    Legend,
    Tooltip,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
} from "recharts";

import pdata from './TestData.jsx';

export default function Graph(){
    return(
        <div>
            <h1>Graafi</h1>
            <ResponsiveContainer width="100%" aspect={1}>
                <LineChart data={pdata}>
                    <CartesianGrid />
                    <XAxis dataKey="kilometers" interval={"preserveStartEnd"} />
                    <YAxis></YAxis>
                    <Legend />
                    <Tooltip />
                    <Line
                        dataKey="litres"
                        stroke="yellow"
                        activeDot={{ r: 8 }}
                    />
                    <Line dataKey="price" stroke="green" activeDot={{ r: 8 }} />
                </LineChart>
            </ResponsiveContainer>
        </div>
    );
}